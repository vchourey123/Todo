# Javascript Basics

A Pen created on CodePen.io. Original URL: [https://codepen.io/vdeqode/pen/mdxoBaY](https://codepen.io/vdeqode/pen/mdxoBaY).

